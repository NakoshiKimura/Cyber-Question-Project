from __future__ import annotations
import os, json, uuid, datetime, secrets, hashlib
from pathlib import Path
from typing import Dict, Any, List
from flask import Flask, render_template, request, redirect, url_for, send_file, send_from_directory, flash, jsonify, render_template_string

APP_NAME = "SG Vendor Cyber Maturity (v2.1)"
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
UPLOADS = BASE / "uploads"
REPORTS = BASE / "reports"
STATIC_DIR = BASE / "static"
OUTBOX = DATA / "outbox.json"
TOKENS = DATA / "tokens.json"
RESP_DIR = DATA / "responses"
SG_RED = "#E30613"

# ✅ Added: comments store path (used by /api/comment and dashboard)
COMMENTS = DATA / "comments.json"

for p in [UPLOADS, REPORTS, RESP_DIR]:
    p.mkdir(parents=True, exist_ok=True)

def jload(p: Path, d):
    try:
        return json.loads(p.read_text())
    except Exception:
        return d

def jdump(p: Path, o):
    p.write_text(json.dumps(o, indent=2))

def now():
    return datetime.datetime.utcnow().isoformat()+"Z"

def hash_filename(filename: str) -> str:
    safe = "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in filename)
    h = hashlib.sha1((safe+str(uuid.uuid4())).encode()).hexdigest()[:10]
    if "." in safe:
        n,e = safe.rsplit(".",1)
        return f"{n}_{h}.{e}"
    return f"{safe}_{h}"

# Data files
VENDORS = DATA / "vendors.json"
QUESTIONS = DATA / "questions.json"
EVIDENCE = DATA / "evidence_catalog.json"
SERVICES = DATA / "services.json"
MAPPING = DATA / "mapping.json"
WEIGHTS = DATA / "weights.json"
MAT_THRESH = DATA / "maturity_thresholds.json"
RISK_MATRIX = DATA / "risk_matrix.json"

def compute_scores(answers: Dict[str,str]) -> Dict[str,Any]:
    weights = jload(WEIGHTS, {})
    qs = {q["id"]: q for q in jload(QUESTIONS, [])}
    dom_tot = {}
    dom_got = {}
    for qid, q in qs.items():
        dom = q["domain"]
        w_map = weights.get(qid, {})
        max_w = max([float(x) for x in w_map.values()], default=1.0) if isinstance(w_map, dict) else 1.0
        dom_tot[dom] = dom_tot.get(dom, 0.0) + max_w
    for qid, ans in answers.items():
        q = qs.get(qid); 
        if not q: continue
        dom = q["domain"]
        w_map = weights.get(qid, {})
        val = 0.0
        if isinstance(w_map, dict):
            if ans in w_map: val = float(w_map[ans])
            else:
                for k,v in w_map.items():
                    if str(ans).lower().startswith(str(k).lower()):
                        val = float(v); break
        else:
            a = str(ans).strip().lower()
            val = 1.0 if a == "yes" else (0.5 if a=="na" else 0.0)
        dom_got[dom] = dom_got.get(dom, 0.0) + val
    domain_pct = {}
    for d in dom_tot:
        domain_pct[d] = round(100.0 * dom_got.get(d,0.0) / dom_tot[d], 1) if dom_tot[d] else 0.0
    overall = round(sum(dom_got.values())/max(1.0,sum(dom_tot.values()))*100.0, 1) if dom_tot else 0.0

    thresh = jload(MAT_THRESH, {})
    level = "Very Mature"; color = "blue"
    for name, cfg in thresh.items():
        mn = float(cfg.get("min",0)); mx = float(cfg.get("max",100))
        if overall >= mn and overall < mx:
            level = name; color = cfg.get("color","blue"); break
    return {"domain_pct": domain_pct, "overall_pct": overall, "maturity": level, "maturity_color": color}

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY","dev")

@app.context_processor
def inject():
    logo = url_for("static_file", filename="sg_logo_white.png") if (STATIC_DIR/"sg_logo_white.png").exists() else None
    return {"app_name": APP_NAME, "sg_red": SG_RED, "sg_logo": logo}

from flask import url_for

@app.route("/static/<path:filename>")
def static_file(filename):
    return send_from_directory(STATIC_DIR, filename)

@app.route("/")
def home():
    return redirect(url_for("type_of_service"))

@app.route("/type-of-service", methods=["GET","POST"])
def type_of_service():
    vendors = jload(VENDORS, [])
    mapping = jload(MAPPING, {})
    services = jload(SERVICES, list(mapping.keys()))
    if request.method == "POST":
        vendor_id = request.form.get("vendor_id")
        body = request.form.get("body","")
        services_sel = request.form.getlist("services")
        v = next((x for x in vendors if x["id"]==vendor_id), None)
        if not v:
            flash("Vendor not found","error")
            return redirect(url_for("type_of_service"))
        if not services_sel: services_sel = v.get("services",[])
        token = secrets.token_urlsafe(24)
        tokens = jload(TOKENS, {}); tokens[token] = {"vendor_id": vendor_id, "created": now()}; jdump(TOKENS, tokens)
        out = jload(OUTBOX, [])
        out.append({"token": token, "vendor_id": vendor_id, "vendor_name": v["name"], "email": v["email"], "services": services_sel, "body": body, "created": now()})
        jdump(OUTBOX, out)
        flash("Queued to Outbox (demo).","success")
        return redirect(url_for("outbox"))
    return render_template("type_of_service.html", vendors=vendors, services=services)

@app.route("/run-scheduler")
def run_scheduler():
    vendors = jload(VENDORS, [])
    out = jload(OUTBOX, [])
    tokens = jload(TOKENS, {})
    today = datetime.date.today()
    for v in vendors:
        try:
            dt = datetime.date.fromisoformat(v["review_date"])
        except Exception:
            continue
        if 0 <= (dt - today).days <= 60:
            token = secrets.token_urlsafe(24)
            tokens[token] = {"vendor_id": v["id"], "created": now()}
            out.append({"token": token, "vendor_id": v["id"], "vendor_name": v["name"], "email": v["email"], "services": v.get("services",[]), "body": "Automated scheduling (demo).", "created": now()})
    jdump(OUTBOX, out); jdump(TOKENS, tokens)
    flash("Auto-scheduler queued vendors within 60 days of review date.","success")
    return redirect(url_for("outbox"))

@app.route("/outbox")
def outbox():
    out = jload(OUTBOX, [])
    return render_template("outbox.html", outbox=out)

@app.route("/email-preview-log")
def email_preview_log():
    out = jload(OUTBOX, [])
    return render_template("email_preview_log.html", outbox=out)

@app.route("/form/<token>", methods=["GET"])
def vendor_form(token):
    tokens = jload(TOKENS, {})
    info = tokens.get(token)
    if not info: return "Invalid token", 404
    vendors = jload(VENDORS, [])
    v = next((x for x in vendors if x["id"]==info["vendor_id"]), None)
    if not v: return "Unknown vendor", 404
    out = jload(OUTBOX, [])
    entry = next((o for o in out if o["token"]==token), None)
    services = entry.get("services") if entry else v.get("services",[])

    mapping = jload(MAPPING, {})
    qs_all = jload(QUESTIONS, [])
    qids = []
    for s in services:
        qids += mapping.get(s, [])
    qset = [q for q in qs_all if (not qids) or (q["id"] in qids)]
    resp_file = RESP_DIR / f"{v['id']}.json"
    draft = jload(resp_file, {"answers":{}, "evidence":{}})

    # ✅ Ensure evidence dict is present and required domains exist even if DOCX lacks them
    evidence = jload(EVIDENCE, {})
    for _dom in ['Change and Release Management', 'Cloud', 'AI']:
        evidence.setdefault(_dom, {})
        if not evidence[_dom]:
            evidence[_dom] = {"General": []}

    return render_template(
        "form.html",
        vendor=v,
        services=services,
        questions=qset,
        answers=draft.get("answers", {}),
        evidence=evidence,
        token=token,
        errors=[],
        error_banner=False,
    )

@app.post("/api/autosave/<token>")
def autosave(token):
    info = jload(TOKENS, {}).get(token)
    if not info: return jsonify({"ok":False,"message":"Invalid token"}), 400
    v_id = info["vendor_id"]
    answers = {}
    for k,v in request.form.items():
        if k.startswith("ans_"): answers[k[4:]] = v
    resp_file = RESP_DIR / f"{v_id}.json"
    data = jload(resp_file, {"answers":{}, "evidence":{}})
    data["answers"].update(answers)
    jdump(resp_file, data)
    return jsonify({"ok":True,"message":"Draft saved"})

@app.post("/submit/<token>")
def submit_form(token):
    tokens = jload(TOKENS, {})
    info = tokens.get(token)
    if not info: return "Invalid token", 400
    v_id = info["vendor_id"]

    qlist = jload(QUESTIONS, [])
    optmap = {q["id"]: [str(o).strip() for o in q.get("options",[])] for q in qlist}

    answers = {}
    for k,v in request.form.items():
        if k.startswith("ans_"): answers[k[4:]] = v

    # Validate strictly against ResponseSet
    missing = []
    for q in qlist:
        qid = q["id"]
        opts = optmap.get(qid, [])
        val = answers.get(qid, "").strip()
        if not val or (opts and val not in opts):
            missing.append(qid)

    if missing:
        vendors = jload(VENDORS, [])
        v = next((x for x in vendors if x["id"]==v_id), None)
        entry = next((o for o in jload(OUTBOX, [] ) if o["token"]==token), None)
        services = entry.get("services") if entry else v.get("services",[])
        resp_file = RESP_DIR / f"{v['id']}.json"
        draft = jload(resp_file, {"answers":{}, "evidence":{}})
        draft["answers"].update(answers)
        jdump(resp_file, draft)
        mapping = jload(MAPPING, {})
        qids = []
        for s in services: qids += mapping.get(s, [])
        qset = [q for q in qlist if (not qids) or (q["id"] in qids)]
        return render_template("form.html", vendor=v, services=services, questions=qset, answers=answers, evidence=jload(EVIDENCE, {}), token=token, errors=missing, error_banner=True)

    # Evidence uploads
    evidence_saved = {}
    for k,file in request.files.items():
        if not file or file.filename=="": continue
        if k.startswith("evidence_file_"):
            key = k.replace("evidence_file_","")
            dom, sub = key.split("__",1)
            doc_select = request.form.get(f"evidence_doc_{dom}__{sub}", "")
            dest = UPLOADS / v_id / dom / sub
            dest.mkdir(parents=True, exist_ok=True)
            fname = hash_filename(file.filename)
            fpath = dest / fname
            file.save(fpath)
            evidence_saved.setdefault(dom, {}).setdefault(sub, []).append(doc_select or file.filename)

    # Save final
    resp_file = RESP_DIR / f"{v_id}.json"
    data = jload(resp_file, {"answers":{}, "evidence_names":{}})
    data["answers"] = answers
    for dom, subs in evidence_saved.items():
        for sub, docs in subs.items():
            key = f"{dom}::{sub}"
            data.setdefault("evidence_names", {}).setdefault(key, [])
            data["evidence_names"][key] += docs
    data["scores"] = compute_scores(data.get("answers",{}))
    data["submitted_at"] = now()
    jdump(resp_file, data)

    return render_template("thank_you.html", evidence_summary=evidence_saved)

@app.route("/dashboard")
def dashboard():
    vendors = jload(VENDORS, [])
    vendor_id = request.args.get("vendor_id","")
    comments = jload(COMMENTS, {})
    table = []
    summary = None
    if vendor_id:
        data = jload(RESP_DIR / f"{vendor_id}.json", {"answers":{}, "evidence_names":{}})
        qs = jload(QUESTIONS, [])
        for q in qs:
            ans = data["answers"].get(q["id"])
            comp = "-" 
            if ans is not None:
                aa = str(ans).lower()
                comp = "Compliant" if aa.startswith("yes") else ("Partially Compliant" if aa.startswith("na") else "Non-Compliant")
            evk = f"{q['domain']}::{q['subdomain']}"
            ev = data.get("evidence_names",{}).get(evk, [])
            table.append({"domain": q["domain"], "subdomain": q["subdomain"], "text": q["text"], "answer": ans, "compliance": comp, "evidence": ev, "comment": comments.get(vendor_id, {}).get(q["id"], ""), "qid": q["id"]})
        summary = data.get("scores") or compute_scores(data.get("answers",{}))
    return render_template("dashboard.html", vendors=vendors, vendor_id=vendor_id, table=table, summary=summary)

@app.route("/ai-review")
def ai_review_redirect():
    return redirect(url_for("dashboard"))

@app.route("/generate-report/<vendor_id>/<int:step>")
def generate_report(vendor_id, step):
    from docx import Document
    vendors = jload(VENDORS, [])
    v = next((x for x in vendors if x["id"]==vendor_id), None)
    if not v: return "Unknown vendor", 404
    titles = {
        1: f"{v['name']} Maturity Assessment (Questionnaire).docx",
        2: f"{v['name']} Evidence Review.docx",
        3: f"{v['name']} Recommended Follow-up Questions.docx",
        4: f"{v['name']} Cybersecurity Risk Analysis.docx",
    }
    doc = Document()
    doc.add_heading(titles[step], 0)
    doc.add_paragraph(f"Vendor: {v['name']}  |  Email: {v['email']}  |  Services: {', '.join(v.get('services', []))}")
    data = jload(RESP_DIR / f"{vendor_id}.json", {"answers":{}, "evidence_names":{}, "scores":{}})
    if step == 1:
        doc.add_heading("Questionnaire Summary", level=1)
        for q in jload(QUESTIONS, []):
            a = data["answers"].get(q["id"], "-")
            doc.add_paragraph(f"[{q['id']}] {q['text']}  -> {a}")
    elif step == 2:
        doc.add_heading("Evidence Review", level=1)
        for k, names in data.get("evidence_names",{}).items():
            doc.add_paragraph(f"{k}: {', '.join(names)}")
    elif step == 3:
        doc.add_heading("Recommended Follow-up Questions", level=1)
        for qid, a in data.get("answers",{}).items():
            if str(a).lower().startswith("no"):
                qtext = next((qq['text'] for qq in jload(QUESTIONS, []) if qq['id']==qid), qid)
                doc.add_paragraph(f"Follow-up on: [{qid}] {qtext}")
    elif step == 4:
        scores = data.get("scores") or compute_scores(data.get("answers",{}))
        doc.add_heading("Risk Analysis (Inherent / Residual)", level=1)
        doc.add_paragraph(f"Overall Maturity: {scores.get('maturity')} ({scores.get('overall_pct')}%)")
        for d,p in scores.get("domain_pct",{}).items():
            doc.add_paragraph(f"{d}: {p}%")
    REPORTS.mkdir(exist_ok=True, parents=True)
    fpath = REPORTS / titles[step]
    doc.save(fpath)
    return send_file(fpath, as_attachment=True)

@app.post("/api/comment/<vendor_id>")
def save_comment(vendor_id):
    qid = request.form.get("qid", "").strip()
    text = request.form.get("text", "").strip()
    if not qid:
        return jsonify({"ok": False, "message": "Missing qid"}), 400
    data = jload(COMMENTS, {})
    data.setdefault(vendor_id, {})[qid] = text
    jdump(COMMENTS, data)
    return jsonify({"ok": True})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)