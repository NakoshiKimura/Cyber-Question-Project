import os, json, datetime, secrets, re
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from dateutil.relativedelta import relativedelta
import pandas as pd

app = Flask(__name__)
app.secret_key = "dev"

BASE_DIR = os.path.dirname(__file__)
DATA_DIR = os.path.join(BASE_DIR, "data")
OUTBOX_DIR = os.path.join(BASE_DIR, "outbox")
OUTBOX_PATH = os.path.join(OUTBOX_DIR, "messages.json")

def load_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default

def save_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2)

def get_vendors():
    return load_json(os.path.join(DATA_DIR, "vendors.json"), [])

def get_outbox():
    if not os.path.exists(OUTBOX_PATH):
        save_json(OUTBOX_PATH, [])
    return load_json(OUTBOX_PATH, [])

def load_config():
    return load_json(os.path.join(DATA_DIR, "config_seed.json"), {})

def build_form_url(token):
    return url_for('questionnaire', token=token, _external=True)

def normalize_excel(path):
    xls = pd.ExcelFile(path)
    services = []
    if "Front page" in xls.sheet_names:
        df = pd.read_excel(path, sheet_name="Front page")
        for col in df.columns:
            if str(col).strip().lower().startswith("type of service"):
                services = [str(s).strip() for s in df[col].dropna().tolist() if str(s).strip()]
                break
    questions = []
    if "Maturity Questionnaire EN" in xls.sheet_names:
        df = pd.read_excel(path, sheet_name="Maturity Questionnaire EN")
        colmap = {}
        for col in df.columns:
            low = str(col).lower().strip()
            if low.startswith("domain"): colmap["Domain"] = col
            elif low.startswith("sub"): colmap["Subdomain"] = col
            elif "id" == low or "questionid" in low or low == "id": colmap["QuestionID"] = col
            elif "question" in low: colmap["QuestionText"] = col
        for _, row in df.iterrows():
            try:
                questions.append({
                    "QuestionID": str(row[colmap["QuestionID"]]).strip(),
                    "Domain": str(row[colmap["Domain"]]).strip(),
                    "Subdomain": str(row[colmap["Subdomain"]]).strip(),
                    "QuestionText": str(row[colmap["QuestionText"]]).strip()
                })
            except Exception:
                continue
    mapping = []
    if "Mapping" in xls.sheet_names:
        dfm = pd.read_excel(path, sheet_name="Mapping")
        svc_col = None; q_col = None; questions_col = None
        for c in dfm.columns:
            low = str(c).lower().strip()
            if "service" in low: svc_col = c
            if "questions" == low: questions_col = c
            if "question" in low and "id" in low: q_col = c
        if questions_col and svc_col:
            for _, row in dfm.iterrows():
                st = str(row[svc_col]).strip()
                qids = str(row.get(questions_col, "")).strip()
                if st and qids:
                    for qid in [x.strip() for x in qids.split(",") if x.strip()]:
                        mapping.append({"ServiceType": st, "QuestionID": qid})
        elif svc_col and q_col:
            for _, row in dfm.iterrows():
                st = str(row[svc_col]).strip()
                qid = str(row[q_col]).strip()
                if st and qid:
                    mapping.append({"ServiceType": st, "QuestionID": qid})
    weights = []
    if "Cyber_configuration EN" in xls.sheet_names:
        dfw = pd.read_excel(path, sheet_name="Cyber_configuration EN")
        q_col = None; w_col = None; resp_col=None; d_col=None; s_col=None
        for col in dfw.columns:
            low = str(col).lower().strip()
            if low in ("id","question id","questionid"): q_col = col
            if "weight" in low: w_col = col
            if "response set" in low or low=="response": resp_col = col
            if low.startswith("domain"): d_col = col
            if low.startswith("sub"): s_col = col
        for _, row in dfw.iterrows():
            try:
                w = row[w_col]
                if isinstance(w, str) and w.endswith("%"):
                    w = float(w.replace("%",""))/100.0
                else:
                    w = float(w)
                weights.append({
                    "QuestionID": str(row[q_col]).strip(),
                    "Weight": w,
                    "ResponseSet": (str(row[resp_col]).strip() if resp_col else None),
                    "Domain": (str(row[d_col]).strip() if d_col else None),
                    "Subdomain": (str(row[s_col]).strip() if s_col else None)
                })
            except Exception:
                continue
    evidence = []
    if "Evidence to provide" in xls.sheet_names:
        dfe = pd.read_excel(path, sheet_name="Evidence to provide")
        d_col = None; e_col = None
        for col in dfe.columns:
            low = str(col).lower().strip()
            if low.startswith("domain"): d_col = col
            if "evidence" in low: e_col = col
        if d_col and e_col:
            for _, row in dfe.iterrows():
                dom = str(row[d_col]).strip()
                ev = str(row[e_col]).strip()
                if dom and ev:
                    evidence.append({"Domain": dom, "EvidenceItem": ev})
    cfg = {"services": services or ["All"], "questions": questions, "mapping": mapping, "weights": weights, "evidence": evidence}
    return cfg

def questions_for_service(cfg, service_or_list):
    if isinstance(service_or_list, list): services = service_or_list
    else: services = [service_or_list]
    all_map = [m["QuestionID"] for m in cfg["mapping"] if m["ServiceType"] == "All"]
    qids = set(all_map)
    for s in services:
        qids.update([m["QuestionID"] for m in cfg["mapping"] if m["ServiceType"] == s])
    qdict = {q["QuestionID"]: q for q in cfg["questions"]}
    wmap = {w["QuestionID"]: w for w in cfg.get("weights", [])}
    out = []
    for qid in sorted(list(qids)):
        if qid in qdict:
            item = dict(qdict[qid])
            rs = (wmap.get(qid, {}) or {}).get("ResponseSet")
            if rs and isinstance(rs, str):
                parts = [p.strip() for p in re.split(r'[,/]|\s\|\s', rs) if p.strip()]
                if parts: item["ResponseSetChoices"] = parts
            out.append(item)
    return out

def score_answers(cfg, answers):
    def to_val(ans):
        a = (ans or "").strip().lower()
        if a in ("yes","y","true"): return 1.0
        if a in ("na","n/a"): return 0.5
        return 0.0
    wmap = {w["QuestionID"]: w for w in cfg.get("weights", [])}
    qmeta = {q["QuestionID"]: q for q in cfg.get("questions", [])}
    rows = []; total_w=0.0; total=0.0
    domain_scores={}; domain_w={}; sub_scores={}; sub_w={}
    for qid, ans in answers.items():
        wrec = wmap.get(qid, {}); w = float(wrec.get("Weight",0.0)); total_w += w
        val = to_val(ans); sc = val*w*100.0; total += sc
        meta = qmeta.get(qid, {})
        dom = meta.get("Domain", wrec.get("Domain","Other"))
        sub = meta.get("Subdomain", wrec.get("Subdomain",""))
        domain_scores[dom] = domain_scores.get(dom,0.0)+sc; domain_w[dom]=domain_w.get(dom,0.0)+w
        sub_scores[(dom,sub)] = sub_scores.get((dom,sub),0.0)+sc; sub_w[(dom,sub)]=sub_w.get((dom,sub),0.0)+w
        cl = "Compliant" if val==1.0 else ("Partially Compliant" if val==0.5 else "Not Compliant")
        rows.append({"QuestionID": qid, "Domain":dom, "Subdomain":sub, "Answer": ans, "Weight": w,
                     "OverallScore": sc if w>0 else 0.0, "ComplianceLevel": cl,
                     "ResponseSet": wrec.get("ResponseSet")})
    total_score = (total/total_w) if total_w>0 else 0.0
    labels=[]; values=[]
    for dom, sc in domain_scores.items():
        w = domain_w.get(dom,0.0); labels.append(dom); values.append(sc / w if w>0 else 0.0)
    yes = sum(1 for a in answers.values() if to_val(a)==1.0)
    compliance_pct = (yes/len(answers)*100.0) if answers else 0.0
    domain_summary=[]
    for (dom, sub), sc in sub_scores.items():
        w=sub_w.get((dom,sub),0.0)
        subset=[r for r in rows if r["Domain"]==dom and r["Subdomain"]==sub]
        n=len(subset); n_c=sum(1 for r in subset if r["ComplianceLevel"]=="Compliant")
        n_p=sum(1 for r in subset if r["ComplianceLevel"]=="Partially Compliant")
        n_n=sum(1 for r in subset if r["ComplianceLevel"]=="Not Compliant")
        domain_summary.append({"Domain":dom,"Subdomain":sub,"avg_score":(sc/w if w>0 else 0.0),"n":n,"n_compliant":n_c,"n_partial":n_p,"n_not":n_n})
    return rows, total_score, compliance_pct, labels, values, domain_summary

@app.route("/")
def index():
    vendors = get_vendors()
    cfg = load_config()
    return render_template("index.html", vendors=vendors, services=cfg.get("services",["All"]))

@app.route("/send", methods=["POST"])
def send_now():
    vendor_id = request.form.get("vendor_id")
    vendors = {v["vendor_id"]: v for v in get_vendors()}
    v = vendors[vendor_id]
    service_multi = request.form.getlist("service_multi") or []
    service = ",".join(service_multi) if service_multi else "All"
    token = secrets.token_hex(8)
    msg = {
        "token": token,
        "time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
        "email": v["email"], "vendor_name": v["name"], "vendor_id": v["vendor_id"],
        "service": service
    }
    out = get_outbox()
    out.append(msg); save_json(OUTBOX_PATH, out)
    flash("Queued questionnaire to Outbox (demo email). Open from Outbox.", "success")
    return redirect(url_for("outbox"))

@app.route("/prepare_manual", methods=["POST"])
def prepare_manual():
    data = request.get_json(force=True) or {}
    vendor_id = data.get("vendor_id")
    services = data.get("services") or []
    resend_token = data.get("resend_token")
    vendors = {v["vendor_id"]: v for v in get_vendors()}
    if resend_token:
        ob = get_outbox()
        orig = next((m for m in ob if m.get("token")==resend_token), None)
        if not orig:
            return jsonify({"ok": False, "error":"Original message not found."})
        v = {"vendor_id": orig["vendor_id"], "name": orig["vendor_name"], "email": orig["email"]}
        service = orig.get("service","All")
        subject = orig.get("subject") or "Third-Party Risk Review Questionnaire"
        body_html = orig.get("body_html") or ""
    else:
        v = vendors.get(vendor_id)
        if not v:
            return jsonify({"ok": False, "error":"Vendor not found"})
        service = ",".join(services) if services else "All"
        subject = "Third-Party Risk Review Questionnaire"
        body_html = ""
    token = secrets.token_hex(8)
    msg = {"token": token, "time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
           "email": v["email"], "vendor_name": v["name"], "vendor_id": v["vendor_id"],
           "service": service, "subject": subject, "body_html": body_html, "draft": True}
    out = get_outbox(); out.append(msg); save_json(OUTBOX_PATH, out)
    form_url = build_form_url(token)
    return jsonify({"ok": True, "token": token, "email": v["email"], "vendor_name": v["name"], "form_url": form_url, "subject": subject, "body_html": body_html})

@app.route("/send_manual", methods=["POST"])
def send_manual():
    data = request.get_json(force=True) or {}
    token = data.get("token")
    subject = data.get("subject") or "Third-Party Risk Review Questionnaire"
    body_html = data.get("body_html") or ""
    out = get_outbox()
    msg = next((m for m in out if m.get("token")==token), None)
    if not msg:
        return jsonify({"ok": False, "error":"Draft not found"})
    msg["subject"] = subject
    msg["body_html"] = body_html
    msg["draft"] = False
    save_json(OUTBOX_PATH, out)
    return jsonify({"ok": True})

@app.route("/scheduler", methods=["POST"])
def run_scheduler():
    today = datetime.date.today()
    vendors = get_vendors()
    sent = 0
    for v in vendors:
        rdate = datetime.datetime.strptime(v["risk_review_date"], "%Y-%m-%d").date()
        if rdate - relativedelta(months=2) <= today:
            token = secrets.token_hex(8)
            out = get_outbox()
            out.append({
                "token": token, "time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
                "email": v["email"], "vendor_name": v["name"], "vendor_id": v["vendor_id"],
                "service": "All"
            }); save_json(OUTBOX_PATH, out); sent += 1
    flash(f"Auto-scheduler queued {sent} questionnaire(s).", "success")
    return redirect(url_for("outbox"))

@app.route("/outbox")
def outbox():
    return render_template("outbox.html", messages=get_outbox())

@app.route("/q/<token>", methods=["GET","POST"])
def questionnaire(token):
    msg = next((m for m in get_outbox() if m["token"]==token), None)
    if not msg: return "Invalid token", 404
    cfg = load_config()
    svc_list = [s.strip() for s in (msg.get("service","All") or "All").split(",") if s.strip()]
    qs = questions_for_service(cfg, svc_list)
    from collections import defaultdict
    grouped = defaultdict(list)
    wmap = {w["QuestionID"]: w for w in cfg.get("weights",[])}
    evidence_by_domain = defaultdict(list)
    for e in cfg.get("evidence", []):
        evidence_by_domain[e["Domain"]].append(e)
    for q in qs:
        wrec = wmap.get(q["QuestionID"])
        if wrec and wrec.get("ResponseSet"):
            parts = [p.strip() for p in re.split(r'[,/]|\s\|\s', wrec["ResponseSet"]) if p.strip()]
            if parts: q["ResponseSetChoices"] = parts
        grouped[q["Domain"]].append(q)
    if request.method=="POST":
        answers = {}
        for q in qs:
            key = f"q_{q['QuestionID']}"
            val = (request.form.get(key) or "").strip()
            if not val: 
                flash("All questions must be answered (Yes/No/NA or a valid option).", "danger")
                return render_template("questionnaire.html", vendor=msg, grouped=grouped, evidence_by_domain=evidence_by_domain)
            answers[q["QuestionID"]] = val
        dom_list = list(grouped.keys())
        required = []
        for d_i, dom in enumerate(dom_list):
            for e_i, e in enumerate(evidence_by_domain.get(dom, [])):
                required.append((dom, e["EvidenceItem"], f"ev_{e_i}_{d_i}"))
        missing = []
        uploads_record = []
        upload_root = os.path.join(DATA_DIR, "uploads", msg["token"])
        os.makedirs(upload_root, exist_ok=True)
        for dom, item, field in required:
            files = request.files.getlist(field)
            if not files or all((f.filename.strip()=="" if f else True) for f in files):
                missing.append(f"{dom} -> {item}")
            else:
                dom_dir = os.path.join(upload_root, dom.replace("/", "_"))
                os.makedirs(dom_dir, exist_ok=True)
                saved = []
                for f in files:
                    if not f or not f.filename: 
                        continue
                    safe = f"{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}_{re.sub(r'[^A-Za-z0-9_.-]+','_', f.filename)}"
                    path = os.path.join(dom_dir, safe)
                    f.save(path)
                    saved.append(os.path.relpath(path, DATA_DIR))
                uploads_record.append({"Domain": dom, "EvidenceItem": item, "files": saved})
        if missing:
            flash("Evidence missing for: " + "; ".join(missing), "danger")
            return render_template("questionnaire.html", vendor=msg, grouped=grouped, evidence_by_domain=evidence_by_domain)
        rows, total_score, compliance_pct, labels, values, domain_summary = score_answers(cfg, answers)
        resp_path = os.path.join(DATA_DIR, "vendor_responses.json")
        data = load_json(resp_path, [])
        data.append({"vendor_id": msg["vendor_id"], "vendor_name": msg["vendor_name"], "service": msg["service"],
                     "created_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                     "total_score": total_score, "compliance_pct": compliance_pct, "rows": rows, "evidence": uploads_record})
        save_json(resp_path, data)
        return render_template("results.html", rows=rows, total_score=total_score, compliance_pct=compliance_pct,
                               radar_labels=labels, radar_data=values, evidence=cfg.get("evidence",[]))
    return render_template("questionnaire.html", vendor=msg, grouped=grouped, evidence_by_domain=evidence_by_domain)

@app.route("/admin", methods=["GET"])
def admin():
    cfg = load_config()
    evidence_status = load_json(os.path.join(DATA_DIR, "evidence_status.json"), {})

    # Real radar data from completed responses
    resp_all = load_json(os.path.join(DATA_DIR, "vendor_responses.json"), [])
    domain_scores = {}; domain_weights = {}
    for doc in resp_all:
        for r in doc.get("rows", []):
            dom = r.get("Domain"); w = r.get("Weight",0.0); sc = r.get("OverallScore",0.0)
            domain_scores[dom] = domain_scores.get(dom,0.0)+sc; domain_weights[dom]=domain_weights.get(dom,0.0)+w
    labels=[]; values=[]
    for dom, sc in domain_scores.items():
        w=domain_weights.get(dom,0.0); labels.append(dom); values.append((sc/w) if w>0 else 0.0)

    # Domain-subdomain summary
    agg = {}; uploaded_evidence_counts = {}
    for doc in resp_all:
        for ev in doc.get("evidence", []):
            key = f"{ev['Domain']}|{ev['EvidenceItem']}"
            uploaded_evidence_counts[key] = uploaded_evidence_counts.get(key, 0) + len(ev.get("files", []))
        for r in doc.get("rows", []):
            key = (r["Domain"], r["Subdomain"])
            a = agg.get(key, {"scores": [], "comp": [], "Domain": r["Domain"], "Subdomain": r["Subdomain"]})
            a["scores"].append(r["OverallScore"] / (r["Weight"] if r["Weight"]>0 else 1))
            a["comp"].append(r["ComplianceLevel"])
            agg[key] = a
    domain_summary = []
    for _, a in agg.items():
        n=len(a["scores"]); avg=sum(a["scores"])/n if n else 0.0
        n_c=sum(1 for c in a["comp"] if c=="Compliant")
        n_p=sum(1 for c in a["comp"] if c=="Partially Compliant")
        n_n=sum(1 for c in a["comp"] if c=="Not Compliant")
        domain_summary.append({"Domain":a["Domain"], "Subdomain":a["Subdomain"], "avg_score":avg, "n":n, "n_compliant":n_c, "n_partial":n_p, "n_not":n_n})
    vendors = get_vendors()
    sent = len(get_outbox()); completed = len(resp_all); pending = max(sent-completed,0)
    avg_compliance = sum(x.get("compliance_pct",0) for x in resp_all)/completed if completed else 0.0
    stats = {"total_vendors": len(vendors), "sent": sent, "completed": completed, "pending": pending, "avg_compliance": avg_compliance}

    def strip_html(s):
        import re as _re
        return _re.sub(r'<[^>]*>', '', s or '')
    ob = get_outbox()[::-1][:10]
    email_log = [{
        "time": m.get("time",""),
        "vendor_name": m.get("vendor_name",""),
        "email": m.get("email",""),
        "subject": m.get("subject"),
        "preview": (strip_html(m.get("body_html",""))[:60] + ("..." if len(strip_html(m.get("body_html",""))) > 60 else "")),
        "token": m.get("token"),
        "body_html": m.get("body_html","")
    } for m in ob]

    return render_template("admin.html", cfg=cfg, radar_labels=labels, radar_data=values, evidence_status=evidence_status,
                           domain_summary=domain_summary, stats=stats, uploaded_evidence_counts=uploaded_evidence_counts, email_log=email_log)

@app.route("/update_evidence", methods=["POST"])
def update_evidence():
    selected = request.form.getlist("evidence")
    status = {k: True for k in selected}
    path = os.path.join(DATA_DIR, "evidence_status.json")
    save_json(path, status)
    flash("Evidence status saved.", "success")
    return redirect(url_for("admin"))

@app.route("/upload", methods=["POST"])
def upload_excel():
    f = request.files.get("file")
    if not f: 
        flash("Please choose a file.", "danger")
        return redirect(url_for("admin"))
    tmp = os.path.join(DATA_DIR, "uploaded.xlsx")
    f.save(tmp)
    cfg = normalize_excel(tmp)
    save_json(os.path.join(DATA_DIR, "config_seed.json"), cfg)
    flash("Configuration rebuilt from Excel.", "success")
    return redirect(url_for("admin"))

@app.route("/email-log")
def email_log():
    def strip_html(s):
        import re
        return re.sub(r"<[^>]*>", "", s or "")
    ob = get_outbox()[::-1][:50]
    email_log = [{
        "time": m.get("time",""),
        "vendor_name": m.get("vendor_name",""),
        "email": m.get("email",""),
        "subject": m.get("subject"),
        "preview": (lambda t: (t[:60] + ("..." if len(t) > 60 else "")))(strip_html(m.get("body_html",""))),
        "token": m.get("token"),
    } for m in ob]
    return render_template("email_log.html", email_log=email_log)

@app.route("/view-email/<token>")
def view_email(token):
    msg = next((m for m in get_outbox() if m.get("token")==token), None)
    if not msg:
        return "Message not found", 404
    context = {
        "time": msg.get("time") or msg.get("sent_at") or "",
        "email": msg.get("email") or "",
        "subject": msg.get("subject") or "Third-Party Risk Review Questionnaire",
        "body_html": msg.get("body_html") or msg.get("html_body") or "<p>(empty)</p>"
    }
    return render_template("view_email.html", **context)


# ----------------------------
# AI Review Portal (v4.4)
# ----------------------------
import datetime, random, json, os
from flask import render_template, request, redirect, url_for

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
os.makedirs(DATA_DIR, exist_ok=True)

def read_file(path):
    return open(path, "r", encoding="utf-8").read() if os.path.exists(path) else ""

def load_json(path, default=None):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return default or {}

def save_json(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def perform_ai_review(doc_path, prompt):
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    score = random.randint(70, 95)
    exec_summary = "Simulated AI review summary for demonstration."
    key_controls = [["Access Control", "RBAC defined", "Unauthorized access", "IT Security"]]
    recs = [{"priority": "High", "text": "Add MFA enforcement"}]
    checklist = ["Verify backup procedure", "Test DR plan"]
    return {
        "filename": os.path.basename(doc_path),
        "reviewed_at": now,
        "score": score,
        "exec_summary": exec_summary,
        "key_controls": key_controls,
        "recommendations": recs,
        "checklist": checklist,
        "prompt_snapshot": prompt
    }

@app.route("/ai-review")
def ai_review():
    prompt_path = os.path.join(DATA_DIR, "ai_prompt.txt")
    reviews_path = os.path.join(DATA_DIR, "ai_reviews.json")
    docs_dir = os.path.join(DATA_DIR, "vendor_docs")
    os.makedirs(docs_dir, exist_ok=True)

    ai_prompt = read_file(prompt_path)
    ai_reviews = load_json(reviews_path, {})
    docs = []
    for f in sorted(os.listdir(docs_dir)):
        if f.lower().endswith((".txt", ".pdf", ".docx", ".md")):
            rec = ai_reviews.get(f, {})
            docs.append({"filename": f, "score": rec.get("score"), "date": rec.get("reviewed_at")})

    scores = [r.get("score", 0) for r in ai_reviews.values() if isinstance(r, dict)]
    ai_score = sum(scores) / len(scores) if scores else 0
    questionnaire_score = 80
    final_score = round(0.6 * questionnaire_score + 0.4 * ai_score, 1)

    return render_template(
        "ai_review.html",
        ai_prompt=ai_prompt,
        docs=docs,
        ai_score=ai_score,
        questionnaire_score=questionnaire_score,
        final_score=final_score
    )

@app.route("/save_prompt", methods=["POST"])
def save_prompt():
    text = request.form.get("prompt", "")
    with open(os.path.join(DATA_DIR, "ai_prompt.txt"), "w", encoding="utf-8") as f:
        f.write(text)
    return redirect(url_for("ai_review"))

@app.route("/run_ai_review", methods=["POST"])
def run_ai_review():
    docs_dir = os.path.join(DATA_DIR, "vendor_docs")
    prompt = read_file(os.path.join(DATA_DIR, "ai_prompt.txt"))
    ai_reviews = load_json(os.path.join(DATA_DIR, "ai_reviews.json"), {})
    for f in os.listdir(docs_dir):
        if f.lower().endswith((".txt", ".pdf", ".docx", ".md")):
            ai_reviews[f] = perform_ai_review(os.path.join(docs_dir, f), prompt)
    save_json(os.path.join(DATA_DIR, "ai_reviews.json"), ai_reviews)
    return redirect(url_for("ai_review"))


if __name__ == "__main__":
    app.run(debug=True)

@app.route("/email-log")
def email_log():
    def strip_html(s):
        import re
        return re.sub(r"<[^>]*>", "", s or "")
    ob = get_outbox()[::-1][:50]
    email_log = [{
        "time": m.get("time",""),
        "vendor_name": m.get("vendor_name",""),
        "email": m.get("email",""),
        "subject": m.get("subject"),
        "preview": (lambda t: (t[:60] + ("..." if len(t) > 60 else "")))(strip_html(m.get("body_html",""))),
        "token": m.get("token"),
    } for m in ob]
    return render_template("email_log.html", email_log=email_log)


def load_evidence_status():
    path = os.path.join(DATA_DIR, "evidence_status.json")
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}
    except Exception:
        return {}



def get_uploaded_evidence_counts():
    resp_all = load_json(os.path.join(DATA_DIR, "vendor_responses.json"), [])
    counts = {}
    for doc in resp_all:
        for ev in doc.get("evidence", []):
            key = f"{ev.get('Domain','')}|{ev.get('EvidenceItem','')}"
            counts[key] = counts.get(key, 0) + len(ev.get('files', []))
    return counts



def compute_summary(cfg):
    # Build domain_summary & a simple radar dataset from vendor_responses.json
    resp_all = load_json(os.path.join(DATA_DIR, "vendor_responses.json"), [])
    agg = {}  # (Domain, Subdomain) -> scores, comps
    for doc in resp_all:
        for r in doc.get("rows", []):
            key = (r.get("Domain",""), r.get("Subdomain",""))
            a = agg.get(key, {"scores": [], "comp": [], "Domain": key[0], "Subdomain": key[1]})
            weight = r.get("Weight") or 1.0
            try:
                score = float(r.get("OverallScore", 0.0))
                norm = score / float(weight) if weight else 0.0
            except Exception:
                norm = 0.0
            a["scores"].append(norm)
            a["comp"].append(r.get("ComplianceLevel", ""))
            agg[key] = a

    domain_summary = []
    domain_avg = {}  # Domain -> list of avg per subdomain
    for _, a in agg.items():
        n = len(a["scores"])
        avg = sum(a["scores"])/n*100.0 if n else 0.0
        n_c = sum(1 for c in a["comp"] if c=="Compliant")
        n_p = sum(1 for c in a["comp"] if c=="Partially Compliant")
        n_n = sum(1 for c in a["comp"] if c=="Not Compliant")
        domain_summary.append({
            "Domain": a["Domain"],
            "Subdomain": a["Subdomain"],
            "avg_score": avg,
            "n": n,
            "n_compliant": n_c,
            "n_partial": n_p,
            "n_not": n_n
        })
        domain_avg.setdefault(a["Domain"], []).append(avg)

    # Radar: one value per Domain = avg of subdomain avgs
    labels = sorted(domain_avg.keys())
    data = []
    for d in labels:
        vals = domain_avg[d]
        data.append(sum(vals)/len(vals) if vals else 0.0)
    return domain_summary, labels, data



def get_stats():
    outbox = get_outbox()
    responses = load_json(os.path.join(DATA_DIR, "vendor_responses.json"), [])
    vendors = set(m.get("vendor_name","") for m in outbox)
    stats = {
        "total_vendors": len(vendors) if vendors else 0,
        "sent": len(outbox),
        "completed": sum(1 for r in responses if r.get("status")=="completed"),
        "pending": max(len(outbox) - sum(1 for r in responses if r.get("status")=="completed"), 0),
        "avg_compliance": 0.0
    }
    # rough avg compliance from responses
    all_scores = []
    for r in responses:
        for row in r.get("rows", []):
            weight = row.get("Weight") or 1.0
            try:
                score = float(row.get("OverallScore", 0.0))
                norm = score / float(weight) if weight else 0.0
            except Exception:
                norm = 0.0
            all_scores.append(norm*100.0)
    if all_scores:
        stats["avg_compliance"] = sum(all_scores)/len(all_scores)
    return stats

