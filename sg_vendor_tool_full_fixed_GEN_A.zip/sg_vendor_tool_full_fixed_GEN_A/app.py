
import os, json, datetime, secrets
from flask import Flask, render_template, request, redirect, url_for, send_from_directory, jsonify, abort
from pathlib import Path

APP_ROOT = Path(__file__).parent.resolve()
DATA = APP_ROOT/'data'
UPLOADS = APP_ROOT/'uploads'
OUTBOX = DATA/'outbox'
RESPONSES = DATA/'responses'
AIREV = DATA/'ai_reviews'

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 50*1024*1024

def load_master():
    with open(DATA/'master.json','r',encoding='utf-8') as f: return json.load(f)
def save_json(p, obj):
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p,'w',encoding='utf-8') as f: json.dump(obj,f,indent=2,ensure_ascii=False)
def read_json(p, default=None):
    if p.exists():
        with open(p,'r',encoding='utf-8') as f: return json.load(f)
    return default
def find_vendor(vendors, vid):
    for v in vendors:
        if v['id']==vid: return v
    return None
def questions_for_services(master, service_ids):
    ids=set()
    for m in master['mapping']:
        if m['service_id'] in service_ids: ids.update(m['questions'])
    qs=[q for q in master['questions'] if q['id'] in ids]; qs.sort(key=lambda x:x['id']); return qs
def compliance_level(q, response):
    r = (response or '').lower()
    if r in ['yes','yes - fully tested','yes - fully formalised','every 12 months']: return 'Compliant'
    if r in ['n/a','na']: return 'Partially compliant'
    if 'every' in r and 'months' in r:
        try:
            n=int(r.split('every')[1].split('months')[0].strip())
            return 'Compliant' if n<=12 else 'Not compliant'
        except: pass
    return 'Not compliant'
def maturity_label(score_total, score_max=1100):
    if score_total>=880: return 'Very Mature','success'
    if score_total>=660: return 'Mature','success'
    if score_total>=440: return 'Medium','warn'
    if score_total>=220: return 'Poor','danger'
    return 'Very Poor','danger'

@app.route('/')
def type_of_service():
    master=load_master()
    items = sorted([p for p in OUTBOX.glob('*.json')], key=lambda p:p.stat().st_mtime, reverse=True)
    return render_template('type_of_service.html', title='Type of Service', vendors=master['vendors'], services=master['services'], mapping=master['mapping'], outbox_count=len(items))

@app.post('/send_manual')
def send_manual():
    master=load_master()
    vid = request.form.get('vendor_id'); vendor = find_vendor(master['vendors'], vid)
    services = [int(s) for s in request.form.getlist('services')]
    subject = request.form.get('subject','SG Cyber Maturity Questionnaire'); body = request.form.get('body','')
    token = secrets.token_urlsafe(10)
    item = {"queued_at": datetime.datetime.now().strftime('%Y-%m-%d %H:%M'),"vendor_id": vendor['id'], "vendor_name": vendor['name'],"email": vendor['email'],"subject": subject,"body": body,"services": services,"token": token,"status": "Queued"}
    save_json(OUTBOX/f"{token}.json", item)
    log = read_json(DATA/'email_log.json', default=[]); log.append({"time": item['queued_at'], "vendor": vendor['name'], "subject": subject, "token": token}); save_json(DATA/'email_log.json', log)
    return redirect(url_for('outbox'))

@app.get('/run_scheduler')
def run_scheduler():
    master=load_master(); today = datetime.date.today(); queued=0
    for v in master['vendors']:
        rd = datetime.date.fromisoformat(v['review_date'])
        if 0 <= (rd - today).days <= 60:
            exists = any(read_json(item).get('vendor_id')==v['id'] for item in OUTBOX.glob('*.json'))
            if exists: continue
            token = secrets.token_urlsafe(10)
            item = {"queued_at": datetime.datetime.now().strftime('%Y-%m-%d %H:%M'),"vendor_id": v['id'], "vendor_name": v['name'],"email": v['email'],"subject": "SG Cyber Maturity Questionnaire","body": "Auto scheduled","services": v.get('services',[]),"token": token,"status": "Queued"}
            save_json(OUTBOX/f"{token}.json", item); queued+=1
            log = read_json(DATA/'email_log.json', default=[]); log.append({"time": item['queued_at'], "vendor": v['name'], "subject": item['subject'], "token": token}); save_json(DATA/'email_log.json', log)
    return redirect(url_for('outbox'))

@app.get('/outbox')
def outbox():
    items = sorted([read_json(p) for p in OUTBOX.glob('*.json')], key=lambda x:x['queued_at'], reverse=True)
    return render_template('outbox.html', items=items, title='Outbox')

@app.get('/email-log')
def email_log():
    logs = read_json(DATA/'email_log.json', default=[]); logs = list(reversed(logs))
    return render_template('email_log.html', logs=logs, title='Email Log')

@app.get('/form/<token>')
def vendor_form(token):
    item = read_json(OUTBOX / f"{token}.json")
    if not item: abort(404)
    master=load_master(); vendor = find_vendor(master['vendors'], item['vendor_id'])
    qs = questions_for_services(master, item['services'] or [])
    return render_template('vendor_form.html', vendor=vendor, service_ids = [str(s) for s in item['services']], service_names=[s['name'] for s in master['services'] if s['id'] in item['services']], questions=qs, token=token, evidence_options=master['evidence_options'])

@app.post('/form/<token>/autosave')
def autosave_vendor_form(token):
    data = request.json; save_json(RESPONSES/f"{token}_autosave.json", data or {}); return jsonify({"ok":True})

@app.post('/form/<token>/submit')
def submit_vendor_form(token):
    item = read_json(OUTBOX/f"{token}.json")
    if not item: abort(404)
    master=load_master(); vendor = find_vendor(master['vendors'], item['vendor_id'])
    payload = {"vendor_id":vendor['id'], "services":item['services'], "submitted_at": datetime.datetime.now().isoformat(), "answers":[], "evidences":[]}
    for q in questions_for_services(master, item['services']):
        rid = request.form.get(f"resp_{q['id']}","").strip() or "N/A"
        cmt = request.form.get(f"cmt_{q['id']}","").strip()
        ev_label = request.form.get(f"ev_label_{q['id']}","").strip()
        file = request.files.get(f"ev_file_{q['id']}"); ev_path=None
        if file and file.filename:
            safe = f"{vendor['id']}_{q['id'].replace('.','_')}_{int(datetime.datetime.now().timestamp())}_{file.filename}"
            dest = UPLOADS/safe; file.save(dest); ev_path = f"/uploads/{safe}"
        payload["answers"].append({"id":q['id'], "response":rid, "comment":cmt})
        if ev_label or ev_path: payload["evidences"].append({"id":q['id'], "label":ev_label, "file":ev_path})
    sid = datetime.datetime.now().strftime('%Y%m%d_%H%M%S'); save_json(RESPONSES/f"{vendor['id']}_{sid}.json", payload)
    item['status']="Submitted"; save_json(OUTBOX/f"{token}.json", item)
    return redirect(url_for('dashboard', vendor=vendor['id']))

@app.get('/uploads/<path:name>')
def uploaded(name): return send_from_directory(UPLOADS, name, as_attachment=True)

@app.get('/dashboard')
def dashboard():
    master=load_master(); vendor_id = request.args.get('vendor'); vendor = next((v for v in master['vendors'] if v['id']==vendor_id), None) if vendor_id else None
    table_rows=[]; domain_scores=[]; maturity={"label":"—","badge":"warn","last_submission":None}
    if vendor:
        files = sorted(RESPONSES.glob(f"{vendor['id']}_*.json"), reverse=True)
        if files:
            data = json.load(open(files[0],'r',encoding='utf-8')); maturity["last_submission"]=data["submitted_at"]
            q_map = {q['id']:q for q in master['questions']}; domain_acc={}
            for ans in data['answers']:
                q = q_map.get(ans['id'], {"domain":"Other","subdomain":"—","question":ans['id']})
                comp = compliance_level(q, ans['response'])
                docrec = next((ev['file'] for ev in data.get('evidences',[]) if ev['id']==ans['id'] and ev.get('file')), None)
                table_rows.append({"domain": q['domain'], "subdomain": q.get('subdomain','—'), "id": ans['id'], "question": q['question'], "response": ans['response'], "compliance": comp, "document": bool(docrec), "document_url": docrec or ''})
                sc = 100 if comp=='Compliant' else (50 if comp.startswith('Partially') else 0)
                d = q['domain']; domain_acc.setdefault(d,{"sum":0,"n":0}); domain_acc[d]["sum"]+=sc; domain_acc[d]["n"]+=1
            domain_scores = [{"domain":d, "score":round(v["sum"]/max(1,v["n"]))} for d,v in domain_acc.items()]; domain_scores.sort(key=lambda x:x['domain'])
            total = sum(d["score"] for d in domain_scores) * 11
            label,badge = maturity_label(total); maturity["label"]=label; maturity["badge"]= "success" if 'Mature' in label else ("warn" if label=='Medium' else "danger")
    return render_template('dashboard.html', vendors=master['vendors'], vendor=vendor, table_rows=table_rows, domain_scores=domain_scores, maturity=maturity)

# DOCX writer (minimal, no external libs)
def write_simple_docx(path, text):
    from zipfile import ZipFile, ZIP_DEFLATED
    rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>'
    doc = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>','<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">','<w:body>']
    for line in text.split('\\n'):
        if not line.strip(): doc.append('<w:p/>')
        else:
            t = line.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
            doc.append(f'<w:p><w:r><w:t>{t}</w:t></w:r></w:p>')
    doc.append('<w:sectPr/></w:body></w:document>')
    with ZipFile(path,'w',ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>')
        z.writestr('_rels/.rels', rels)
        z.writestr('word/document.xml',''.join(doc))

def synthesize_text_from_submission(vendor_id):
    files = sorted(RESPONSES.glob(f"{vendor_id}_*.json"), reverse=True)
    if not files: return "No submission found."
    data = json.load(open(files[0],'r',encoding='utf-8')); master = load_master(); q_map = {q['id']:q for q in master['questions']}
    lines = [f"Vendor: {vendor_id}", f"Submitted at: {data['submitted_at']}", "", "Answers:"]
    for a in data['answers']:
        q=q_map.get(a['id'],{"question":a['id']}); lines.append(f"- [{a['id']}] {q['question']} -> {a['response']} ({a.get('comment','')})")
    lines.append(""); lines.append("Evidences:")
    for e in data.get('evidences',[]): lines.append(f"- [{e['id']}] {e.get('label','')} : {e.get('file','')}")
    return '\\n'.join(lines)

@app.get('/ai-review')
def ai_review():
    master=load_master(); vendor_id = request.args.get('vendor'); vendor = next((v for v in master['vendors'] if v['id']==vendor_id), None) if vendor_id else None
    steps=[{"key":"step1","title":"Step 1 — Maturity Assessment (Questionnaire)","desc":"Summarize strengths/weaknesses from the questionnaire."},
           {"key":"step2","title":"Step 2 — Evidence Review","desc":"Compare questionnaire vs. uploaded evidences."},
           {"key":"step3","title":"Step 3 — Recommended Follow-up Questions","desc":"Generate target questions for clarification."},
           {"key":"step4","title":"Step 4 — Cybersecurity Risk Analysis","desc":"Use Risk Matrix to summarize inherent vs residual risk."}]
    if vendor:
        for s in steps:
            outs = sorted((AIREV/vendor['id']/s['key']).glob('*.docx'), reverse=True)
            if outs:
                rel = outs[0].relative_to(APP_ROOT)
                s['output']={"name":outs[0].name,"time":datetime.datetime.fromtimestamp(outs[0].stat().st_mtime).strftime('%Y-%m-%d %H:%M'),"url": f"/download/{rel.as_posix()}"}
    return render_template('ai_review.html', vendors=master['vendors'], vendor=vendor, steps=steps)

@app.post('/ai-review/<step>')
def generate_ai_doc(step):
    vendor_id = request.form.get('vendor_id'); 
    if not vendor_id: abort(400)
    headings = {"step1":"Maturity Assessment (Questionnaire)","step2":"Evidence Review","step3":"Recommended Follow-up Questions","step4":"Cybersecurity Risk Analysis"}
    title = headings.get(step, step)
    text = synthesize_text_from_submission(vendor_id)
    doc_text = f"{title}\\n\\n{text}\\n\\nGenerated by demo — replace with GPT-5 prompt outputs."
    outdir = AIREV/vendor_id/step; outdir.mkdir(parents=True, exist_ok=True)
    fname = f"{vendor_id}_{title.replace(' ','_')}.docx"; fpath = outdir/fname; write_simple_docx(fpath, doc_text)
    return redirect(url_for('ai_review', vendor=vendor_id))

@app.get('/download/<path:relpath>')
def download_rel(relpath):
    full = APP_ROOT/relpath
    if not full.exists(): abort(404)
    return send_from_directory(full.parent, full.name, as_attachment=True)

if __name__=='__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
