python -m venv venv

venv\Scripts\activate

pip install flask python-docx pandas openpyxl pillow

python app.py

http://localhost:8000