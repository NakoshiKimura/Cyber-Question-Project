
TPRM Tool v3.8.1 – Société Générale Internal
=============================================

Features
--------
- Fixed SG-style navbar: Dashboard | Admin | Outbox | Email Preview Log
- Evidence internal-only (opened from Admin)
- Email Preview Log:
    * Live refresh every 10s
    * 🟢 / ⏸ toggle
    * “Last updated Xs ago”
    * 👁 View → opens /view-email/<token>
    * 🔁 Resend → modal editor with last message
- SG favicon, spinner, and corporate white/red/black theme

Run
---
    venv\Scripts\activate
    pip install -r requirements.txt
    python app.py
    (open http://127.0.0.1:5000)
