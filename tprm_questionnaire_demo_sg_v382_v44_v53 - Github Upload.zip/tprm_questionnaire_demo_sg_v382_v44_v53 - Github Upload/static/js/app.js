function renderRadar(labels, values){
  const ctx = document.getElementById('radar');
  if(!ctx) return;
  if(!labels || labels.length===0){ ctx.parentElement.innerHTML = '<div class="text-muted">No data yet</div>'; return; }
  new Chart(ctx, { type: 'radar', data: { labels, datasets: [{ label: 'Domain Score', data: values }] },
                   options: { scales: { r: { suggestedMin: 0, suggestedMax: 100 } } } });
}

// Manual compose & resend
let quill, composeModal;
function initQuill(){ if(quill) return; const el=document.getElementById('quillEditor'); if(!el) return; quill = new Quill('#quillEditor',{theme:'snow',modules:{toolbar:[['bold','italic','underline'],[{list:'ordered'},{list:'bullet'}],['link']]}}); }
function gatherServices(){ return Array.from(document.querySelectorAll('input[name="service_multi"]:checked')).map(i=>i.value); }
function openManualCompose(prefill){
  initQuill();
  const to = prefill?.to || document.querySelector('#vendor_id option:checked')?.dataset.email || '';
  const modalEl = document.getElementById('composeModal');
  if(!modalEl){ return; }
  composeModal = new bootstrap.Modal(modalEl);
  document.getElementById('manual_to').value = to;
  document.getElementById('manual_subject').value = prefill?.subject || 'Third-Party Risk Review Questionnaire';
  document.getElementById('manual_token').value = prefill?.token || '';
  if(quill){ quill.root.innerHTML = prefill?.body_html || ''; }
  composeModal.show();
}
async function prepareManualDraft(resendToken){
  const vendorSel = document.getElementById('vendor_id');
  const vendor_id = vendorSel ? vendorSel.value : null;
  const services = gatherServices();
  const resp = await fetch('/prepare_manual',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({vendor_id, services, resend_token:resendToken||null})});
  const data = await resp.json();
  if(!data.ok){ alert(data.error||'Failed to prepare'); return; }
  const linkHtml = `<p>Please complete your questionnaire here: <a href="${data.form_url}" target="_blank">${data.form_url}</a></p>`;
  openManualCompose({to:data.email, subject:data.subject, token:data.token, body_html:(data.body_html||'')+linkHtml});
}
async function sendManual(){
  const token=document.getElementById('manual_token').value;
  const subject=document.getElementById('manual_subject').value;
  const body_html=quill?quill.root.innerHTML:'';
  const resp=await fetch('/send_manual',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token, subject, body_html})});
  const data=await resp.json();
  if(!data.ok){ alert(data.error||'Failed to send'); return; }
  composeModal?.hide(); window.location='/outbox';
}
document.addEventListener('DOMContentLoaded',()=>{
  const openBtn=document.getElementById('openManual'); if(openBtn){openBtn.addEventListener('click',()=>prepareManualDraft(null));}
  const sendBtn=document.getElementById('sendManualBtn'); if(sendBtn){sendBtn.addEventListener('click', sendManual);}
});
// Delegate click for admin resend
document.addEventListener('click', (e) => {
  const b = e.target.closest('.btn-resend');
  if (!b) return;
  const token = b.getAttribute('data-token');
  prepareManualDraft(token);
});